<?php

define('NAME', 'sdfsf');

return [];