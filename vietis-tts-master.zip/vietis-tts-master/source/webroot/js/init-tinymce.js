tinymce.init({
	selector : "textarea.tinymce",
	width :   "100%",
	height :   500,
	statubar : true,

});

