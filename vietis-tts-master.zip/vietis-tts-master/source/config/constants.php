<?php 
define('STATUS_ORDER', [
	0=>'Hủy',
	1=>'Đã đặt hàng',
	2=>'Đóng gói',
]);
return [];
